-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- 생성 시간: 16-09-30 04:11
-- 서버 버전: 10.1.16-MariaDB
-- PHP 버전: 5.6.24

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- 데이터베이스: `kccdb`
--

-- --------------------------------------------------------

--
-- 테이블 구조 `member`
--

CREATE TABLE `member` (
  `idx` int(50) NOT NULL,
  `korea_name` varchar(100) NOT NULL,
  `english_name` varchar(100) NOT NULL,
  `year` int(50) NOT NULL,
  `month` int(50) NOT NULL,
  `day` int(50) NOT NULL,
  `id` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `password_check` varchar(100) NOT NULL,
  `homephone` int(50) NOT NULL,
  `middle_homephone` int(50) NOT NULL,
  `last_homephone` int(50) NOT NULL,
  `selphone` int(50) NOT NULL,
  `middle_selphone` int(50) NOT NULL,
  `last_selphone` int(50) NOT NULL,
  `sms` varchar(5) NOT NULL,
  `E-MAIL` varchar(100) NOT NULL,
  `first_post` varchar(100) NOT NULL,
  `second_post` varchar(100) NOT NULL,
  `home_address1` varchar(100) NOT NULL,
  `home_address2` varchar(100) NOT NULL,
  `DM send` varchar(100) NOT NULL,
  `company_name` varchar(100) NOT NULL,
  `op` varchar(100) NOT NULL,
  `office` varchar(100) NOT NULL,
  `first_workpost` int(50) NOT NULL,
  `last_workpost` int(50) NOT NULL,
  `work_address1` varchar(100) NOT NULL,
  `work_address2` varchar(100) NOT NULL,
  `comphone` int(50) NOT NULL,
  `first_comphone` int(50) NOT NULL,
  `second_comphone` int(50) NOT NULL,
  `faxphone` int(50) NOT NULL,
  `first_faxphone` int(50) NOT NULL,
  `seccon_faxphone` int(50) NOT NULL,
  `marry` varchar(100) NOT NULL,
  `marryyear` int(50) NOT NULL,
  `marrymonth` int(50) NOT NULL,
  `marryday` int(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- 덤프된 테이블의 인덱스
--

--
-- 테이블의 인덱스 `member`
--
ALTER TABLE `member`
  ADD PRIMARY KEY (`idx`);

--
-- 덤프된 테이블의 AUTO_INCREMENT
--

--
-- 테이블의 AUTO_INCREMENT `member`
--
ALTER TABLE `member`
  MODIFY `idx` int(50) NOT NULL AUTO_INCREMENT;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
